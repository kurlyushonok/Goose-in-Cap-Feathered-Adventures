﻿using var game = new GooseInCap.Game1();
game.Run();