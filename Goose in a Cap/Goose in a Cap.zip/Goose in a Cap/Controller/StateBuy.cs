﻿namespace GooseInCap;

public enum StateBuy
{
    NotBuy,
    Buy,
    Choose,
    Selected
}