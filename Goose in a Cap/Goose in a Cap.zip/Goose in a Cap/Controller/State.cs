﻿namespace GooseInCap;

public enum State
{
    MainMenu,
    Game, 
    Final, 
    Pause,
    Shop,
    Clue
}