﻿using Microsoft.Xna.Framework.Content;

namespace GooseInCap;

public class Player
{
    public int CountCoins { get; set; }
    public int Record { get; set; }
}
